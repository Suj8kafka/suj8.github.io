const darkModeToggle = document.getElementById('darkModeToggle');
const savedTheme = localStorage.getItem('theme');
const legacyDarkMode = localStorage.getItem('darkMode');
let currentTheme = savedTheme || (legacyDarkMode === 'true' ? 'dark' : 'light');
const scrollPosition = localStorage.getItem('scrollPosition') || 0;

function applyTheme(theme) {
  const isDarkMode = theme === 'dark';
  document.body.classList.toggle('dark', isDarkMode);
  document.body.classList.toggle('dark-mode', isDarkMode);

  if (darkModeToggle) {
    darkModeToggle.textContent = isDarkMode ? '🌞' : '🌙';
    darkModeToggle.setAttribute('aria-pressed', String(isDarkMode));
  }

  localStorage.setItem('theme', theme);
  localStorage.setItem('darkMode', String(isDarkMode));
}

applyTheme(currentTheme);

    // Scroll position
    window.scrollTo(0, scrollPosition);

    // Dark Mode Toggle
    if (darkModeToggle) {
      darkModeToggle.addEventListener('click', () => {
        currentTheme = currentTheme === 'dark' ? 'light' : 'dark';
        applyTheme(currentTheme);
      });
    }

    // Save scroll position
    window.addEventListener('scroll', () => {
      localStorage.setItem('scrollPosition', window.scrollY);
    });


    // <!-- Scroll progress JS -->
    const progressBar = document.getElementById('progressBar');
    if (progressBar) {
      window.addEventListener('scroll', () => {
        const scrollTop = window.scrollY;
        const docHeight = document.body.scrollHeight - window.innerHeight;
        const progress = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;
        progressBar.style.width = progress + '%';
      });
    }
  
// Get the current year
 const currentYear = new Date().getFullYear();
  
 // Set the start year (your website's start year)
 const startYear = 2025;

 // Determine if we should show a year range or just one year
 const copyrightText = (currentYear > startYear) 
   ? `© ${startYear}–${currentYear} Sujeet Khadka`
   : `© ${startYear} Sujeet Khadka`;

 // Insert the copyright text into the footer
 const copyright = document.getElementById('copyright');
 if (copyright) {
   copyright.textContent = copyrightText;
 }
