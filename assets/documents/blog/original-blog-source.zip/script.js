
  const toggleButton = document.getElementById('theme-toggle');
  const rootElement = document.documentElement;

  // Apply saved theme on load
  const savedTheme = localStorage.getItem('theme');
  if (savedTheme === 'dark') {
    rootElement.classList.add('dark');
  } else if (savedTheme === 'light') {
    rootElement.classList.remove('dark');
  }

  // Toggle logic
  toggleButton.addEventListener('click', () => {
    if (rootElement.classList.contains('dark')) {
      rootElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    } else {
      rootElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    }
  });
